$(function() {
  const date = new Date()

  $("#copyright-year").html(date.getFullYear())
})