$(function() {
  // Initialize datatable
  $("#datatable-1").DataTable({
    responsive: true, // Reponsive support
    keys: true // Enable key table extension with default configuration
  })
})
