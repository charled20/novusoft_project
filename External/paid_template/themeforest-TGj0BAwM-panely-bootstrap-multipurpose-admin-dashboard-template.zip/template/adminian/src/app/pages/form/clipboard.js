$(function() {
  // Initialize ClipboardJS to .btn elements
  new ClipboardJS(".btn")
})
