$(function() {
  // Initialize QuillJS
  new Quill("#quill", { theme: "snow" })
})
