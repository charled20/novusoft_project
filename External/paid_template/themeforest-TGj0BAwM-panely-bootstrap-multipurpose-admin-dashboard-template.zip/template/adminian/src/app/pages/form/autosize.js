$(function() {
  // Initialize autosize to textarea
  autosize($(".autosize"))
})
