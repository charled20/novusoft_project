$(function() {
  // Initialize datatable
  $("#datatable-1").DataTable({
    scrollCollapse: true, // Enable scrollable table
    scrollY: "50vh",
    scrollX: true
  })
})
