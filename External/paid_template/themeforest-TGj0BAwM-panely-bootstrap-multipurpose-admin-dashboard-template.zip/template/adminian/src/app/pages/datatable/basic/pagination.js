$(function() {
  // Initialize datatable
  $("#datatable-1").DataTable({
    responsive: true, // Reponsive support
    pagingType: "numbers" // Set custom pagination style
  })
})
