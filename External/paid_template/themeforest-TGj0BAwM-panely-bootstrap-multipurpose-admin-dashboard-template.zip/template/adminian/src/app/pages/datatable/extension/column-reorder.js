$(function() {
  // Initialize datatable
  $("#datatable-1").DataTable({
    responsive: true, // Reponsive support
    colReorder: true // Enable column reorder extension with default configuration
  })
})
