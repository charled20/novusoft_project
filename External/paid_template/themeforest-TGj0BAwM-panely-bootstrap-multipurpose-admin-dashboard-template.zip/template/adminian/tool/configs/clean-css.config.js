// Clean CSS configuration
const cleanCSSConfig = {
  level: {
    1: {
      all: true
    }
  }
}

exports.cleanCSSConfig = cleanCSSConfig
