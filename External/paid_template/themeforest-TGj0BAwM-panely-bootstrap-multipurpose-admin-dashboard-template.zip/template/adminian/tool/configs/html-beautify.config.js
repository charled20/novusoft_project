// HTML Beautify configuration
const HTMLBeautifyConfig = {
  indent_size: 4,
  indent_with_tabs: true,
  preserve_newlines: false,
  end_with_newline: true
}

exports.HTMLBeautifyConfig = HTMLBeautifyConfig