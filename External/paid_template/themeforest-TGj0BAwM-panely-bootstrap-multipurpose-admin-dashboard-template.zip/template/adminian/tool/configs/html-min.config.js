// HTML Minify configuration
const HTMLMinConfig = {
  collapseWhitespace: true,
  removeComments: true
}

exports.HTMLMinConfig = HTMLMinConfig